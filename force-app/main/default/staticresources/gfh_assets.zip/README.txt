GFH assets static resource (demo)
